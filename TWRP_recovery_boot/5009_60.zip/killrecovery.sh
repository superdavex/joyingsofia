#!/sbin/sh


/sbin/busybox tar -xvf /TEMP-TWRP


/sbin/ifconfig eth0 192.168.2.1

setprop service.adb.root 1
setprop service.adb.tcp.port 5555

stop adbd
start adbd

#set fb0 mode
echo U:1024x600p-65 > /sys/devices/fb.210/graphics/fb0/mode

/sbin/busybox killall -9 recovery && echo U:1024x600p-65 > /sys/devices/fb.210/graphics/fb0/mode && /sbin/recovery &


exit 1
