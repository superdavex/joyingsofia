#!/sbin/sh


/sbin/busybox tar -xvf /TEMP-TWRP

sbin/busybox killall -9 recovery && /sbin/recovery &

/sbin/ifconfig eth0 192.168.2.1

setprop service.adb.root 1
setprop service.adb.tcp.port 5555

stop adbd
start adbd

pause

exit 1
