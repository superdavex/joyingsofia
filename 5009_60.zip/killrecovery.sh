#!/sbin/sh
/sbin/busybox tar -xvf /TEMP-TWRP
/sbin/busybox killall -9 recovery && /sbin/recovery &
exit 1
